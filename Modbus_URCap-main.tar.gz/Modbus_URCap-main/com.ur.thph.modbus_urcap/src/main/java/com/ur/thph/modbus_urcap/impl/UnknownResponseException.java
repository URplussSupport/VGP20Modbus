package com.ur.thph.modbus_urcap.impl;

public class UnknownResponseException extends Exception {

}
